from django.contrib import admin
from .models import LikedItem

# Register your models here.

admin.site.register(LikedItem)