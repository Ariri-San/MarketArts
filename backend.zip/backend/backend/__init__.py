from .celery import celery

__all__ = ('celery',)